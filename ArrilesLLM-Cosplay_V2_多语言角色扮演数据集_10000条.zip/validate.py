import json,collections,pathlib
P=pathlib.Path(__file__).resolve().parent
rows=[]
for split in ('train','validation','test'):
    with (P/f'{split}.jsonl').open(encoding='utf-8') as f:
        sub=[json.loads(line) for line in f if line.strip()]
    assert all(r['split']==split for r in sub)
    rows.extend(sub)
assert len(rows)==10000
assert len({r['id'] for r in rows})==10000
assert all(r['messages'][0]['role']=='system' for r in rows)
assert all(all(m['role']==('user' if i%2==1 else 'assistant') for i,m in enumerate(r['messages'][1:],1)) for r in rows)
print('PASS',len(rows),collections.Counter(r['language'] for r in rows))
