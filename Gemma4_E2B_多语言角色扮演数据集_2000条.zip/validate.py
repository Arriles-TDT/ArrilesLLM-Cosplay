import json,sys,collections
from pathlib import Path
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('all_2000.jsonl')
rows=[json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
assert len({r['id'] for r in rows})==len(rows)
assert all([m['role'] for m in r['messages']]==['system','user','assistant','user','assistant'] for r in rows)
assert all(all(isinstance(m['content'],str) and m['content'].strip() for m in r['messages']) for r in rows)
print('records:',len(rows))
print('language:',dict(collections.Counter(r['language'] for r in rows)))
print('genre:',dict(collections.Counter(r['genre'] for r in rows)))
print('split:',dict(collections.Counter(r['split'] for r in rows)))
